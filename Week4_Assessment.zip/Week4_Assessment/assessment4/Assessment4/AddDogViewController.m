//
//  AddDogViewController.m
//  Assessment4
//
//  Created by The Engineerium  on 8/11/14.
//  Copyright (c) 2014 MobileMakers. All rights reserved.
//

#import "AddDogViewController.h"

@interface AddDogViewController ()

@property (weak, nonatomic) IBOutlet UITextField *nameTextField;
@property (weak, nonatomic) IBOutlet UITextField *breedTextField;
@property (weak, nonatomic) IBOutlet UITextField *colorTextField;

@end

@implementation AddDogViewController

- (void)viewDidLoad
{
    [super viewDidLoad];
    [self prefillLabels];
}

-(void) prefillLabels{
    
    self.nameTextField.text = self.actualDog.name;
    self.breedTextField.text = self.actualDog.breed;
    self.colorTextField.text = self.actualDog.color;
}

- (IBAction)onPressedUpdateDog:(UIButton *)sender
{
    [self dismissViewControllerAnimated:YES completion:nil];

    if (self.actualDog){
        //EDIT EXISTING DOG
        [self editCoreData];
        
    } else {
        //NEW DOG
        [self saveCoreData];
    }
}


- (void) saveCoreData{
    
    NSManagedObject *object = [NSEntityDescription insertNewObjectForEntityForName:@"Dog"
                                                            inManagedObjectContext:self.managedObjectContext];
    [object setValue:self.nameTextField.text forKey:@"name"];
    [object setValue:self.breedTextField.text forKey:@"breed"];
    [object setValue:self.colorTextField.text forKey:@"color"];
    [object setValue:self.dogsOwner forKey:@"havePerson"];
    
    NSError *error;
    if (![self.managedObjectContext save:&error]) {
        NSLog(@"Failed to save - error: %@", [error localizedDescription]);
    }
}

- (void) editCoreData{
    
    Dog *dog = (Dog *)[self.managedObjectContext
                                      existingObjectWithID:(NSManagedObjectID *)self.actualDog.objectID
                                      error:nil];

    dog.name = self.nameTextField.text;
    dog.breed = self.breedTextField.text;
    dog.color = self.colorTextField.text;
    dog.havePerson = self.dogsOwner;
    
    [self.managedObjectContext save:nil];
}


    

@end
