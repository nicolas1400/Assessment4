//
//  DogsViewController.m
//  Assessment4
//
//  Created by The Engineerium  on 8/11/14.
//  Copyright (c) 2014 MobileMakers. All rights reserved.
//

#import "DogsViewController.h"
#import "AddDogViewController.h"




@interface DogsViewController () <UITableViewDelegate, UITableViewDataSource>

@property (weak, nonatomic) IBOutlet UITableView *dogsTableView;

@end

@implementation DogsViewController

- (void)viewDidLoad
{
    [super viewDidLoad];
    self.title = @"Dogs";
    
    [self loadCoreData];
    
    NSLog(@"%@", self.dogsOwner.name);
}



- (void) loadCoreData{
    
    NSFetchRequest *request = [[NSFetchRequest alloc]initWithEntityName:@"Dog"];
    
    request.sortDescriptors = [NSArray arrayWithObjects:[NSSortDescriptor sortDescriptorWithKey:@"name" ascending:YES], nil];
    
    self.fetchedResultsController = [[NSFetchedResultsController alloc] initWithFetchRequest:request managedObjectContext:self.managedObjectContext  sectionNameKeyPath:@"name" cacheName:nil ];
    
   // [request setPredicate:[NSPredicate predicateWithFormat:@"liked = %@",[NSNumber numberWithBool: YES]]];
    NSPredicate *predicate = [NSPredicate predicateWithFormat:
                              @"havePerson.name like %@", self.dogsOwner.name];
    [request setPredicate:predicate];
    
    self.fetchedResultsController.delegate = self;
    
    [self.fetchedResultsController performFetch:nil];
    
}



#pragma mark - Core Data autorefresh

-(void) controller:(NSFetchedResultsController *)controller didChangeObject:(id)anObject atIndexPath:(NSIndexPath *)indexPath forChangeType:(NSFetchedResultsChangeType)type newIndexPath:(NSIndexPath *)newIndexPath{
    
    [self.dogsTableView reloadData];
}


#pragma mark - UITableViewDataSource Methods

-(NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return [[self.fetchedResultsController.sections objectAtIndex:section]numberOfObjects];
    
}

-(UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier: mmDogCellIdentifier];
    Dog *this = [self.fetchedResultsController objectAtIndexPath:indexPath];
    cell.textLabel.text = this.name;
    return cell;
}

-(NSInteger)numberOfSectionsInTableView:(UITableView *)tableView{
    
    return self.fetchedResultsController.sections.count;
}



-(void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender{
    
    AddDogViewController *dvc = segue.destinationViewController;
    dvc.managedObjectContext = self.managedObjectContext ;
    
    if ([[segue identifier] isEqualToString:@"mmAddSegue"]) {
        //PASS ONLY THE DOG'S OWNER
        [[segue destinationViewController] setDogsOwner:self.dogsOwner];
        
    } else {
        [[segue destinationViewController] setDogsOwner:self.dogsOwner];
        //PASS BOTH THE DOG'S OWNER AND THE ACTUAL DOG TO EDIT
        NSIndexPath *indexPath = [self.dogsTableView indexPathForSelectedRow];
        NSManagedObject *object = [[self fetchedResultsController] objectAtIndexPath:indexPath];
        [[segue destinationViewController] setActualDog:(Dog *)object];

         }
}



@end
