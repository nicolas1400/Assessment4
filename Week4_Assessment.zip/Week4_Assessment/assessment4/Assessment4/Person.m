//
//  Person.m
//  Assessment4
//
//  Created by Nicolas Semenas on 14/08/14.
//  Copyright (c) 2014 MobileMakers. All rights reserved.
//

#import "Person.h"
#import "Dog.h"


@implementation Person

@dynamic name;
@dynamic haveDog;

@end
