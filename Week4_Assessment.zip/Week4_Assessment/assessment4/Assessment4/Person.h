//
//  Person.h
//  Assessment4
//
//  Created by Nicolas Semenas on 14/08/14.
//  Copyright (c) 2014 MobileMakers. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <CoreData/CoreData.h>

@class Dog;

@interface Person : NSManagedObject

@property (nonatomic, retain) NSString * name;
@property (nonatomic, retain) NSSet *haveDog;
@end

@interface Person (CoreDataGeneratedAccessors)

- (void)addHaveDogObject:(Dog *)value;
- (void)removeHaveDogObject:(Dog *)value;
- (void)addHaveDog:(NSSet *)values;
- (void)removeHaveDog:(NSSet *)values;

@end
