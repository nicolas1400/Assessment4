//
//  AddDogViewController.h
//  Assessment4
//
//  Created by The Engineerium  on 8/11/14.
//  Copyright (c) 2014 MobileMakers. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "Person.h"
#import "Dog.h"

@interface AddDogViewController : UIViewController

@property NSManagedObjectContext *managedObjectContext;
@property (strong, nonatomic) NSFetchedResultsController *fetchedResultsController;

@property (nonatomic,strong) Person * dogsOwner;
@property (nonatomic,strong) Dog * actualDog;



@end
