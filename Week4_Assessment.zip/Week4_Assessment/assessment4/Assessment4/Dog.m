//
//  Dog.m
//  Assessment4
//
//  Created by Nicolas Semenas on 14/08/14.
//  Copyright (c) 2014 MobileMakers. All rights reserved.
//

#import "Dog.h"


@implementation Dog

@dynamic name;
@dynamic breed;
@dynamic color;
@dynamic havePerson;

@end
